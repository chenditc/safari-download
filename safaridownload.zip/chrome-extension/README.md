# safari-download
chrome extension to help download book from safaribooksonline.com

## Install

## Usage

## Disclaimer
